require('dotenv').config();
const multer = require("multer");
const upload = multer();

const express = require("express");
const app = express();

// PostgreSQL connection
const { Pool } = require('pg');
const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: {
    rejectUnauthorized: false
  },
  max: 2
});

// Set EJS as the view engine
app.set("view engine", "ejs");

// Start server
app.listen(process.env.PORT || 5001, () => {
    console.log("Server started (http://localhost:5001/) !");
});

// Home page - display all customers
app.get("/", (req, res) => {
  const sql = "SELECT * FROM CUSTOMER ORDER BY id";
  pool.query(sql, [], (err, result) => {
      let message = "";
      let model = {};
      if (err) {
          message = `Error - ${err.message}`;
      } else {
          message = "Customer list loaded successfully.";
          model = result.rows;
      };
      res.render("index", {
          message: message,
          model: model
      });
  });
});

// Input form for uploading customer data
app.get("/input", (req, res) => {
  res.render("input");
});


app.use(express.urlencoded({ extended: true }));  // Make sure to parse URL-encoded bodies

app.post("/add-customer", (req, res) => {
  const { id, firstname, lastname, state, sales_ytd, sales_prev_year } = req.body;

  const sql = `
    INSERT INTO customer (id, firstname, lastname, state, sales_ytd, sales_prev_year)
    VALUES ($1, $2, $3, $4, $5, $6)
  `;

  pool.query(sql, [id, firstname, lastname, state, sales_ytd, sales_prev_year], (err, result) => {
    if (err) {
      console.error("Insert error:", err);
      return res.status(500).send("Error inserting customer: " + err.message);
    }
    res.send("Customer added successfully!");
  });
});


app.post("/input", upload.single('filename'), (req, res) => {
  if (!req.file || Object.keys(req.file).length === 0) {
    return res.send("Error: Import file not uploaded");
  }

  const buffer = req.file.buffer;
  const lines = buffer.toString().split(/\r?\n/).filter(line => line.trim() !== "");

  lines.forEach((line, index) => {
    const customer = line.split(",");

    if (customer.length !== 6) {
      console.log(`Skipping line ${index + 1} - Incorrect column count`);
      return;
    }

    const sql = `
      INSERT INTO CUSTOMER (id, firstname, lastname, state, sales_ytd, sales_prev_year)
      VALUES ($1, $2, $3, $4, $5, $6)
    `;

    pool.query(sql, customer, (err, result) => {
      if (err) {
        console.log(`Line ${index + 1} Insert Error: ${err.message}`);
      } else {
        console.log(`Line ${index + 1} inserted successfully`);
      }
    });
  });

  const message = `Processing Complete - Processed ${lines.length} records`;
  res.send(message);
});


// Custom page (optional)
app.get("/custom", (req, res) => {
    res.render("custom");
});

// Export customers to CSV
app.get("/output", (req, res) => {
  res.render("output", { message: "" });
});

app.post("/output", (req, res) => {
  const sql = `
  INSERT INTO customer (id, firstname, lastname, state, sales_ytd, sales_prev_year)
  VALUES ($1, $2, $3, $4, $5, $6)
`;
  pool.query(sql, [], (err, result) => {
    if (err) {
      return res.render("output", { message: `Error - ${err.message}` });
    }

    let output = "ID,First Name,Last Name,State,Sales YTD,Previous Year Sales\r\n";
    result.rows.forEach(customer => {
      output += `${customer.id},${customer.firstname},${customer.lastname},${customer.state},${customer.sales_ytd},${customer.sales_prev_year}\r\n`;
    });

    res.header("Content-Type", "text/csv");
    res.attachment("customers_export.csv");
    return res.send(output);
  });
});

console.log("DATABASE_URL:", process.env.DATABASE_URL);